package principal;

import layout.Janela;

public class IniciarCliente {

    public static void main(String[] args) {
        Janela janela = new Janela();
    }
}
